#include <iostream>
using namespace std;

int main () {
    cout << "OTHLLO GAME\n";
    return 0;
}
